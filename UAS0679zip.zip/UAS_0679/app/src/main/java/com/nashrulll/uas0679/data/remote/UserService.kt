package com.nashrulll.uas0679.data.remote

import com.cheonajjang.uas0710.data.model.DetailUser
import com.cheonajjang.uas0710.data.model.User
import com.cheonajjang.uas0710.data.model.UserList
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface UserService {

    @GET("search/users")
    @Headers("Authorization: token 46ef4aaa2d1599897fbaf167ec6aca3b9fb7873e")
    fun searchUser(@Query("q") query: String) : Call<UserList>

    @GET("users/{username}")
    @Headers("Authorization: token 46ef4aaa2d1599897fbaf167ec6aca3b9fb7873e")
    fun detailUser(@Path("username") username: String) : Call<DetailUser>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 46ef4aaa2d1599897fbaf167ec6aca3b9fb7873e")
    fun getFollowers(@Path("username") username: String) : Call<ArrayList<User>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 46ef4aaa2d1599897fbaf167ec6aca3b9fb7873e")
    fun getFollowing(@Path("username") username: String) : Call<ArrayList<User>>

}

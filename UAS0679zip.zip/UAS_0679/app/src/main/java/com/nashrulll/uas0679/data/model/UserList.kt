package com.nashrulll.uas0679.data.model

data class UserList(
val items: ArrayList<User>

)
